

<?php $__env->startSection('pageTitle', 'Chat Logs'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto">
        <h1 class="text-2xl font-bold mb-6 text-gray-900 dark:text-white">Chat Logs</h1>
        <?php if($sessions->count() === 0): ?>
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-12 text-center">
                <div class="w-20 h-20 bg-gray-100 dark:bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="message-square-dashed" class="w-10 h-10 text-gray-400"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 dark:text-white">No Chat Logs Found</h3>
                <p class="text-gray-500 dark:text-gray-400 max-w-sm mx-auto mt-2">No chat sessions have been started yet.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse text-sm">
                    <thead class="bg-gray-50 dark:bg-gray-700/50 text-gray-500 dark:text-gray-400 uppercase">
                        <tr>
                            <th class="px-4 py-3">Session ID</th>
                            <th class="px-4 py-3">Document Name</th>
                            <th class="px-4 py-3">Date</th>
                            <th class="px-4 py-3">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                        <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $firstDocChat = $session->chats->first(function($chat) { return $chat->document; });
                                $doc = $firstDocChat ? $firstDocChat->document : null;
                            ?>
                            <tr>
                                <td class="px-4 py-3 font-mono text-primary-700 dark:text-primary-300"><?php echo e($session->session_id); ?></td>
                                <td class="px-4 py-3">
                                    <?php if($doc): ?>
                                        <span class="font-semibold text-gray-900 dark:text-white"><?php echo e($doc->original_name); ?></span>
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3 text-xs text-gray-500">
                                    <?php if($doc): ?>
                                        <?php echo e($doc->created_at ? $doc->created_at->format('M d, Y H:i') : '-'); ?>

                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>
                                <td class="px-4 py-3">
                                    <a href="<?php echo e(route('admin.chatlogs.show', $session->id)); ?>" class="text-blue-600 hover:underline">View Details</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-8"><?php echo e($sessions->links()); ?></div>
            <div class="mt-8"><?php echo e($sessions->links()); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Web Development\chatbot-backend\resources\views\admin\chatlogs.blade.php ENDPATH**/ ?>