

<?php $__env->startSection('pageTitle', 'System Settings'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .tab-content {
        display: none;
    }
    .tab-content.active {
        display: block;
    }
    .tab-button.active {
        background-color: #3B82F6;
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 dark:text-white">System Settings</h1>
        <p class="mt-2 text-sm text-gray-600 dark:text-gray-400">Manage your application settings and configurations</p>
    </div>

    <!-- Success Message -->
    <?php if(session('success')): ?>
    <div class="mb-6 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg dark:bg-green-900 dark:border-green-700 dark:text-green-200">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <!-- Error Messages -->
    <?php if($errors->any()): ?>
    <div class="mb-6 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg dark:bg-red-900 dark:border-red-700 dark:text-red-200">
        <ul class="list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Settings Card -->
    <div class="bg-white dark:bg-gray-800 rounded-lg shadow">
        <!-- Tabs -->
        <div class="border-b border-gray-200 dark:border-gray-700">
            <nav class="flex flex-wrap -mb-px" aria-label="Tabs">
                <button type="button" class="tab-button active px-6 py-4 text-sm font-medium border-b-2 border-transparent hover:border-gray-300 dark:text-gray-300 dark:hover:border-gray-600" data-tab="general">
                    General
                </button>
                <button type="button" class="tab-button px-6 py-4 text-sm font-medium border-b-2 border-transparent hover:border-gray-300 dark:text-gray-300 dark:hover:border-gray-600" data-tab="ai_chat">
                    AI & Chat
                </button>
                <button type="button" class="tab-button px-6 py-4 text-sm font-medium border-b-2 border-transparent hover:border-gray-300 dark:text-gray-300 dark:hover:border-gray-600" data-tab="documents">
                    Documents
                </button>
                <button type="button" class="tab-button px-6 py-4 text-sm font-medium border-b-2 border-transparent hover:border-gray-300 dark:text-gray-300 dark:hover:border-gray-600" data-tab="appearance">
                    Appearance
                </button>
                <button type="button" class="tab-button px-6 py-4 text-sm font-medium border-b-2 border-transparent hover:border-gray-300 dark:text-gray-300 dark:hover:border-gray-600" data-tab="security">
                    Security
                </button>
            </nav>
        </div>

        <!-- Form -->
        <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>

            <!-- Tab Contents -->
            <div class="p-6">
                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupSettings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="<?php echo e($group); ?>" class="tab-content <?php echo e($loop->first ? 'active' : ''); ?>">
                    <div class="space-y-6">
                        <?php $__currentLoopData = $groupSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="setting-field">
                                <label for="<?php echo e($setting['key']); ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            <?php echo e($setting['label']); ?>

                                        </label>

                                        <?php if($setting['type'] === 'text'): ?>
                                <input 
                                    type="text" 
                                    name="<?php echo e($setting['key']); ?>" 
                                    id="<?php echo e($setting['key']); ?>" 
                                    value="<?php echo e(old($setting['key'], $setting['value'])); ?>"
                                    placeholder="<?php echo e($setting['placeholder'] ?? ''); ?>"
                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                >

                            <?php elseif($setting['type'] === 'textarea'): ?>
                                <textarea 
                                    name="<?php echo e($setting['key']); ?>" 
                                    id="<?php echo e($setting['key']); ?>" 
                                    rows="4"
                                    placeholder="<?php echo e($setting['placeholder'] ?? ''); ?>"
                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                ><?php echo e(old($setting['key'], $setting['value'])); ?></textarea>

                            <?php elseif($setting['type'] === 'number'): ?>
                                <input 
                                    type="number" 
                                    name="<?php echo e($setting['key']); ?>" 
                                    id="<?php echo e($setting['key']); ?>" 
                                    value="<?php echo e(old($setting['key'], $setting['value'])); ?>"
                                    placeholder="<?php echo e($setting['placeholder'] ?? ''); ?>"
                                    step="<?php echo e($setting['step'] ?? '1'); ?>"
                                    min="<?php echo e($setting['min'] ?? ''); ?>"
                                    max="<?php echo e($setting['max'] ?? ''); ?>"
                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                >

                            <?php elseif($setting['type'] === 'boolean'): ?>
                                <div class="flex items-center">
                                    <input 
                                        type="checkbox" 
                                        name="<?php echo e($setting['key']); ?>" 
                                        id="<?php echo e($setting['key']); ?>" 
                                        value="1"
                                        <?php echo e(old($setting['key'], $setting['value']) == '1' ? 'checked' : ''); ?>

                                        class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                    >
                                    <label for="<?php echo e($setting['key']); ?>" class="ml-2 text-sm text-gray-600 dark:text-gray-400">
                                        Enable this option
                                    </label>
                                </div>

                            <?php elseif($setting['type'] === 'image'): ?>
                                <div class="space-y-3">
                                    <?php if($setting['value']): ?>
                                        <div class="mb-3">
                                            <img 
                                                src="<?php echo e(asset('storage/' . $setting['value'])); ?>" 
                                                alt="<?php echo e($setting['label']); ?>"
                                                class="h-20 w-auto object-contain border border-gray-200 dark:border-gray-600 rounded p-2 bg-white dark:bg-gray-700"
                                            >
                                        </div>
                                    <?php endif; ?>
                                    <input 
                                        type="file" 
                                        name="<?php echo e($setting['key']); ?>" 
                                        id="<?php echo e($setting['key']); ?>" 
                                        accept="image/*"
                                        class="block w-full text-sm text-gray-500 dark:text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-blue-900 dark:file:text-blue-200"
                                    >
                                </div>

                            <?php elseif($setting['type'] === 'select'): ?>
                                <select 
                                    name="<?php echo e($setting['key']); ?>" 
                                    id="<?php echo e($setting['key']); ?>"
                                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                >
                                    <?php $__currentLoopData = $setting['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionValue => $optionLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option 
                                            value="<?php echo e($optionValue); ?>" 
                                            <?php echo e(old($setting['key'], $setting['value']) == $optionValue ? 'selected' : ''); ?>

                                        >
                                            <?php echo e($optionLabel); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>

                            <?php if(isset($setting['help'])): ?>
                                <p class="mt-1 text-sm text-gray-500 dark:text-gray-400"><?php echo e($setting['help']); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Form Actions -->
            <div class="px-6 py-4 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-600 rounded-b-lg flex justify-end space-x-3">
                <button 
                    type="button" 
                    onclick="window.location.reload()"
                    class="px-6 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-600 font-medium"
                >
                    Reset
                </button>
                <button 
                    type="submit"
                    class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium"
                >
                    Save Settings
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tabName = button.getAttribute('data-tab');

            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            document.getElementById(tabName).classList.add('active');
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Web Development\chatbot-backend\resources\views\admin\settings\index.blade.php ENDPATH**/ ?>