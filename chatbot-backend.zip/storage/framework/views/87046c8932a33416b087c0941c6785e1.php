<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['variant' => 'primary', 'size' => 'md', 'href' => null, 'onclick' => null, 'type' => 'button', 'disabled' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['variant' => 'primary', 'size' => 'md', 'href' => null, 'onclick' => null, 'type' => 'button', 'disabled' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $baseClasses = 'inline-flex items-center justify-center font-medium rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed';

    $variantClasses = [
        'primary' => 'text-white bg-primary-600 hover:bg-primary-700 focus:ring-primary-500',
        'secondary' => 'text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 focus:ring-primary-500 dark:text-gray-300 dark:bg-gray-800 dark:border-gray-600 dark:hover:bg-gray-700',
        'danger' => 'text-white bg-red-600 hover:bg-red-700 focus:ring-red-500',
    ];

    $sizeClasses = [
        'sm' => 'px-3 py-2 text-sm',
        'md' => 'px-4 py-2 text-sm',
        'lg' => 'px-6 py-3 text-base',
    ];

    $classes = $baseClasses . ' ' . $variantClasses[$variant] . ' ' . $sizeClasses[$size];
?>

<?php if($href): ?>
    <a href="<?php echo e($href); ?>" class="<?php echo e($classes); ?>" <?php if($onclick): ?> onclick="<?php echo e($onclick); ?>" <?php endif; ?>>
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <button type="<?php echo e($type); ?>" class="<?php echo e($classes); ?>" <?php if($onclick): ?> onclick="<?php echo e($onclick); ?>" <?php endif; ?> <?php if($disabled): ?> disabled <?php endif; ?> id="<?php echo e($attributes->get('id')); ?>">
        <?php echo e($slot); ?>

    </button>
<?php endif; ?><?php /**PATH E:\Web Development\chatbot-backend\resources\views/components/admin/button.blade.php ENDPATH**/ ?>