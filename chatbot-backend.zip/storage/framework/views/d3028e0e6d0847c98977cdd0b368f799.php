

<?php $__env->startSection('pageTitle', 'Chat Session Detail'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-3xl mx-auto">
        <a href="<?php echo e(route('admin.chatlogs')); ?>" class="text-xs text-blue-600 hover:underline mb-4 inline-block">&larr; Back to Chat Logs</a>
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow border border-gray-100 dark:border-gray-700 p-6 mb-6">
            <h2 class="text-lg font-semibold text-primary-700 dark:text-primary-300 mb-1">Session: <span class="font-mono"><?php echo e($session->session_id); ?></span></h2>
            <div class="text-xs text-gray-500 mb-2">Started: <?php echo e($session->created_at->format('M d, Y H:i')); ?></div>
            <div class="flex flex-wrap gap-4 text-xs text-gray-400 mb-2">
                <?php if($session->user_id): ?>
                    <span>User ID: <?php echo e($session->user_id); ?></span>
                <?php endif; ?>
                <?php if($session->current_document_id): ?>
                    <span>Current Document ID: <?php echo e($session->current_document_id); ?></span>
                <?php endif; ?>
                <span>Total Messages: <?php echo e($session->chats->count()); ?></span>
            </div>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
                <thead class="bg-gray-50 dark:bg-gray-700/50 text-gray-500 dark:text-gray-400 uppercase">
                    <tr>
                        <th class="px-3 py-2">Role</th>
                        <th class="px-3 py-2">Message</th>
                        <th class="px-3 py-2">Time</th>
                        <th class="px-3 py-2">Document</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    <?php $__currentLoopData = $session->chats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-3 py-2 font-semibold <?php echo e($chat->role === 'user' ? 'text-primary-600 dark:text-primary-400' : 'text-gray-600 dark:text-gray-300'); ?>">
                                <i data-lucide="<?php echo e($chat->role === 'user' ? 'user' : 'bot'); ?>" class="inline w-4 h-4 mr-1"></i>
                                <?php echo e(ucfirst($chat->role)); ?>

                            </td>
                            <td class="px-3 py-2 text-gray-900 dark:text-gray-100 whitespace-pre-line"><?php echo e($chat->message); ?></td>
                            <td class="px-3 py-2 text-xs text-gray-500"><?php echo e($chat->created_at->format('M d, Y H:i')); ?></td>
                            <td class="px-3 py-2 text-xs text-gray-400">
                                <?php if($chat->document): ?>
                                    <?php echo e($chat->document->original_name); ?>

                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Web Development\chatbot-backend\resources\views/admin/chatlog-detail.blade.php ENDPATH**/ ?>